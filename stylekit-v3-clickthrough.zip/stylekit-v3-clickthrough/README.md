# Style Kit v3 click-through

An iPhone-sized click-through of the Style Kit v3 design (91 screens, 712 links, 97 in-place controls), exported from Figma.
Open `index.html` through any static web server, or publish this folder with GitHub Pages.

## Publish with GitHub Pages
1. Put the contents of this folder at the root of a repository (or in a `docs/` folder) and push.
2. On GitHub: Settings → Pages → Build and deployment → Deploy from a branch → choose the branch and `/ (root)` (or `/docs`) → Save.
3. After a minute the page is live at `https://<your-user>.github.io/<repository>/`.

## Modes
- **Review**: browse every screen, jump from the screen list, show hotspots (H), Back (←), Restart (R).
- **Test**: enter a participant ID and run the six tasks. Off claude.ai, results stay in the browser tab: use **Export** to download or copy the tasks CSV and the taps CSV after each session. They are not saved anywhere else.

The source of truth is the Figma file; this folder is a snapshot.
