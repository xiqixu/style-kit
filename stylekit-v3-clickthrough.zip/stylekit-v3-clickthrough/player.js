/* Style Kit v3 click-through — player engine.
   Renders screens from screens.json (chrome / scrolling content / above layers),
   runs hotspots (click, drag, timer), transitions and a Back history, and interactive components:
   a screen's states (Figma Change-to variants) swap a patch image in place and keep their value
   per screen until restart().
   window.Player.create(root, data, {start, base, reducedMotion}) → api */
(function () {
  'use strict';
  const FW = 393, FH = 852, DRAG_PX = 8, FLASH_MS = 400, STATE_MS = 150;
  const INSTANT = { type: 'instant', ms: 0 };
  const EASE = [0.2, 0.8, 0.2, 1];
  const CSS = `
.sk-player{position:relative;width:${FW}px;height:${FH}px;overflow:hidden;background:#EDECEB;user-select:none;-webkit-user-select:none;touch-action:manipulation;-webkit-tap-highlight-color:transparent;isolation:isolate}
.sk-scr{position:absolute;inset:0;background:#EDECEB;overflow:hidden}
.sk-scr img{position:absolute;left:0;top:0;width:${FW}px;height:${FH}px;pointer-events:none;-webkit-user-drag:none;user-select:none}
.sk-scroll{position:absolute;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:none}
.sk-scroll::-webkit-scrollbar{display:none}
.sk-inner{position:relative}
.sk-hscroll{position:absolute;overflow-x:auto;overflow-y:hidden;overscroll-behavior-x:contain;scrollbar-width:none}
.sk-hscroll::-webkit-scrollbar{display:none}
.sk-hinner{position:relative}
.sk-scr .sk-hinner img{position:absolute;left:0;top:0}
.sk-scr:focus{outline:none}
.sk-scr .sk-inner img{position:absolute}
.sk-hs{position:absolute;margin:0;padding:0;border:0;border-radius:8px;background:transparent;cursor:pointer;-webkit-appearance:none;appearance:none;font:inherit;color:transparent}
.sk-hs[data-drag]{touch-action:none;cursor:grab}
.sk-hs:focus-visible{outline:2px solid #D88470;outline-offset:2px}
.sk-player.show-hs .sk-hs,.sk-player.flash .sk-hs{background:rgba(216,132,112,.26);box-shadow:inset 0 0 0 1.5px rgba(216,132,112,.95)}
.sk-player.flash .sk-hs{animation:sk-flash ${FLASH_MS}ms ease-out forwards}
@keyframes sk-flash{0%{opacity:1}70%{opacity:1}100%{opacity:0}}
.sk-block{position:absolute}
.sk-state{position:absolute;pointer-events:none}
.sk-state .sk-hs{pointer-events:auto}
.sk-scr .sk-state img{left:0;top:0;width:100%;height:100%;opacity:0;transition:opacity ${STATE_MS}ms ease-out}
.sk-scr .sk-state img.on{opacity:1}
.sk-player.sk-rm .sk-state img{transition:none}
.sk-live{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}`;

  function injectCss() {
    if (document.getElementById('sk-player-css')) return;
    const st = document.createElement('style'); st.id = 'sk-player-css'; st.textContent = CSS;
    document.head.appendChild(st);
  }
  const el = (tag, cls) => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };
  const px = (e, b) => { e.style.left = b.x + 'px'; e.style.top = b.y + 'px'; e.style.width = b.w + 'px'; e.style.height = b.h + 'px'; return e; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const mirror = b => [1 - b[2], 1 - b[3], 1 - b[0], 1 - b[1]];
  const bez = b => `cubic-bezier(${b.join(',')})`;

  // Consecutive hotspots on the same box are one Figma node with several triggers (e.g. click + drag).
  function groupHotspots(list) {
    const out = [];
    for (const h of list) {
      if (h.trigger === 'timer') continue;
      const z = h.layer === 'content' ? 'content' : (h.z || 'below');
      const hs = h.hscroll || null; // inside a sideways-scrolling row: the box is relative to the row's strip
      const g = out[out.length - 1];
      if (g && g.z === z && g.hs === hs && g.x === h.x && g.y === h.y && g.w === h.w && g.h === h.h && g.label === h.label && !g[h.trigger]) {
        g[h.trigger] = h; g.ids.push(h.id);
      } else out.push({ ids: [h.id], z, hs, x: h.x, y: h.y, w: h.w, h: h.h, label: h.label, click: null, drag: null, [h.trigger]: h });
    }
    return out;
  }

  // Keyframes in the forward sense: A is the screen being left, B the one arriving.
  function plan(t) {
    const d = t.direction;
    const axis = (d === 'up' || d === 'down') ? 'Y' : 'X';
    const sign = (d === 'right' || d === 'down') ? -1 : 1;
    const tr = v => `translate${axis}(${v}%)`;
    switch (t.type) {
      case 'push': return { top: 'B', B: [{ transform: tr(100 * sign) }, { transform: tr(0) }], A: [{ transform: tr(0) }, { transform: tr(-30 * sign) }], ease: EASE };
      case 'moveIn': {
        const ax = d === 'left' || d === 'right' ? 'X' : 'Y', s = d === 'right' || d === 'down' ? -1 : 1;
        return { top: 'B', B: [{ transform: `translate${ax}(${100 * s}%)` }, { transform: `translate${ax}(0)` }], A: null, ease: EASE };
      }
      case 'moveOut': {
        const ax = d === 'left' || d === 'right' ? 'X' : 'Y', s = d === 'up' || d === 'left' ? -1 : 1;
        return { top: 'A', A: [{ transform: `translate${ax}(0)` }, { transform: `translate${ax}(${100 * s}%)` }], B: null, ease: EASE };
      }
      case 'smart': return { top: 'B', B: [{ opacity: 0 }, { opacity: 1 }], A: [{ opacity: 1 }, { opacity: 0 }], ease: [0.4, 0, 0.2, 1] };
      default: return { top: 'B', B: [{ opacity: 0 }, { opacity: 1 }], A: null, ease: [0.4, 0, 0.2, 1] }; // dissolve, fade
    }
  }

  function create(root, data, opts) {
    opts = opts || {};
    injectCss();
    const base = opts.base || '';
    const reduced = opts.reducedMotion != null ? !!opts.reducedMotion
      : !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    const byId = Object.create(null);
    for (const s of data.screens) byId[s.id] = s;
    const nameOf = id => (byId[id] ? byId[id].name : id);

    root.classList.add('sk-player');
    root.classList.toggle('sk-rm', reduced);
    root.setAttribute('role', 'region');
    root.setAttribute('aria-label', 'Prototype screen');
    const live = el('div', 'sk-live'); live.setAttribute('aria-live', 'polite'); root.appendChild(live);

    const listeners = { navigate: [], tap: [] };
    const emit = (type, ev) => { for (const fn of listeners[type]) { try { fn(ev); } catch (e) { console.error(e); } } };
    const groupOf = new WeakMap();
    const cache = new Map();
    const preloaded = new Set();
    let cur = null, curEl = null, hist = [], busyFlag = false, timers = [], running = [], press = null, flashT = 0;
    let gen = 0; // bumped by every transition and restart: a transition that is no longer the latest stops before arriving
    let stateVal = Object.create(null);     // screenId → {stateId: variant} for states changed since restart
    const stateEls = Object.create(null);   // screenId → {stateId: {wrap, st, imgs, shown}} for built screens

    function img(src, cls) { const i = el('img', cls); i.alt = ''; i.decoding = 'async'; i.draggable = false; i.src = base + src; return i; }

    function hsButton(g) {
      const b = px(el('button', 'sk-hs'), g);
      b.type = 'button';
      b.dataset.hs = g.ids.join(' ');
      if (g.drag) b.dataset.drag = '';
      const a = (g.click || g.drag).action;
      b.setAttribute('aria-label', a.kind === 'back' ? 'Back' : nameOf(a.to));
      groupOf.set(b, g);
      return b;
    }

    // ---- interactive components ----
    const short = v => v.split(', ').map(p => p.split('=').pop()).join(', ');
    const valueOf = (sid, st) => (stateVal[sid] && stateVal[sid][st.id]) || st.initial;
    function stateButtons(sid, rec, name) {
      const focused = rec.wrap.contains(document.activeElement) ? document.activeElement : null;
      const was = focused && groupOf.get(focused);
      for (const b of [...rec.wrap.querySelectorAll('.sk-hs')]) b.remove();
      let firstB = null, sameB = null, nearB = null, nearD = Infinity;
      for (const h of rec.st.variants[name].hotspots) {
        const b = px(el('button', 'sk-hs'), h);
        b.type = 'button';
        b.dataset.stateHs = rec.st.id; b.dataset.to = h.to;
        b.setAttribute('aria-label', `${h.label || rec.st.label}: ${short(h.to)}`);
        groupOf.set(b, { ids: [], x: h.x, y: h.y, w: h.w, h: h.h, label: h.label, drag: null,
          click: { id: rec.st.id + ':' + h.to, trigger: 'click', label: h.label, action: { kind: 'state', screen: sid, state: rec.st.id, to: h.to } } });
        rec.wrap.appendChild(b); firstB = firstB || b;
        if (was) { // keyboard focus follows the same control: by its label, else the nearest one
          if (!sameB && h.label === was.label) sameB = b;
          const d = Math.hypot(h.x + h.w / 2 - (was.x + was.w / 2), h.y + h.h / 2 - (was.y + was.h / 2));
          if (d < nearD) { nearD = d; nearB = b; }
        }
      }
      const next = sameB || nearB || firstB;
      if (focused && next) next.focus({ preventScroll: true });
    }
    function showState(sid, rec, name, animate) {
      if (rec.shown === name) return;
      const next = rec.imgs[name] || null;
      for (const [n, i] of Object.entries(rec.imgs)) {
        if (n === name) continue;
        // the outgoing patch stays up until the incoming one has faded in over it, so the old look never flashes through
        i.style.transitionDelay = next && animate ? STATE_MS + 'ms' : '0ms';
        if (!animate) i.style.transition = 'none';
        i.classList.remove('on');
      }
      if (next) {
        next.parentNode.appendChild(next);
        next.style.transitionDelay = '0ms'; next.style.transition = animate ? '' : 'none';
        next.classList.add('on');
      }
      if (!animate) { void rec.wrap.offsetWidth; for (const i of Object.values(rec.imgs)) i.style.transition = ''; }
      rec.shown = name;
      stateButtons(sid, rec, name);
    }
    function buildStates(s) {
      const recs = stateEls[s.id] = Object.create(null);
      const out = { content: [], below: [], above: [] };
      for (const st of s.states || []) {
        const wrap = px(el('div', 'sk-state'), st.box);
        wrap.dataset.state = st.id;
        const pat = el('div'); pat.style.cssText = 'position:absolute;inset:0';
        wrap.appendChild(pat);
        const imgs = Object.create(null);
        for (const [name, v] of Object.entries(st.variants)) if (v.img) { imgs[name] = img(v.img, 'sk-patch'); pat.appendChild(imgs[name]); }
        const rec = recs[st.id] = { wrap, st, imgs, shown: null };
        showState(s.id, rec, valueOf(s.id, st), false);
        out[st.layer === 'content' ? 'content' : st.layer === 'above' ? 'above' : 'below'].push({ el: wrap, box: st.box });
      }
      return out;
    }
    function setState(sid, stateId, name) {
      const s = byId[sid], st = s && (s.states || []).find(x => x.id === stateId);
      if (!st || !st.variants[name]) return false;
      (stateVal[sid] = stateVal[sid] || Object.create(null))[stateId] = name;
      const rec = stateEls[sid] && stateEls[sid][stateId];
      if (rec) showState(sid, rec, name, !reduced);
      return true;
    }
    function statesOf(sid) {
      const s = byId[sid || cur]; const out = {};
      for (const st of (s && s.states) || []) out[st.id] = valueOf(s.id, st);
      return out;
    }
    function clearStates() {
      stateVal = Object.create(null);
      for (const sid of Object.keys(stateEls)) for (const rec of Object.values(stateEls[sid])) showState(sid, rec, rec.st.initial, false);
    }

    function build(s) {
      const scr = el('div', 'sk-scr');
      scr.dataset.screen = s.id;
      scr.tabIndex = -1; // focus lands here after a navigation
      scr.setAttribute('aria-label', s.name);
      scr.appendChild(img(s.chrome, 'sk-chrome'));
      const groups = groupHotspots(s.hotspots);
      // A state wrapper sits above its layer's image and beneath that layer's navigation hotspots, except that it
      // goes on top of any hotspot (and its blocker) whose box contains it: that is a backdrop it is drawn over,
      // e.g. a sheet's full-frame dim (states never sit under a dim: backdrop copies have none).
      const sw = buildStates(s);
      const inside = (w, g) => g.x <= w.box.x + 0.5 && g.y <= w.box.y + 0.5 && g.x + g.w >= w.box.x + w.box.w - 0.5 && g.y + g.h >= w.box.y + w.box.h - 0.5;
      const anchor = (w, z) => { let a = null; for (const g of groups) if (g.z === z && inside(w, g)) a = g; return a; };
      const placeStates = (parent, list, z, g) => { for (const w of list) if (anchor(w, z) === g) parent.appendChild(w.el); };
      const blockers = s.blockers || [];
      const addGroup = (parent, g, states) => {
        parent.appendChild(hsButton(g));
        for (const bl of blockers) if (g.ids.includes(bl.after)) parent.appendChild(px(el('div', 'sk-block'), bl));
        placeStates(parent, states, g.z, g);
      };
      placeStates(scr, sw.below, 'below', null);
      for (const g of groups) if (g.z === 'below') addGroup(scr, g, sw.below);
      if (s.content) {
        const c = s.content;
        const sc = px(el('div', 'sk-scroll'), c);
        const inner = el('div', 'sk-inner');
        inner.style.width = c.w + 'px'; inner.style.height = c.contentHeight + 'px';
        const ci = img(c.src, 'sk-content'); ci.style.width = c.w + 'px'; ci.style.height = c.contentHeight + 'px';
        inner.appendChild(ci);
        const strips = Object.create(null);
        for (const r of s.hscroll || []) {
          const box = px(el('div', 'sk-hscroll'), r);
          box.dataset.hscroll = r.id;
          const hi = el('div', 'sk-hinner'); hi.style.width = r.scrollWidth + 'px'; hi.style.height = r.h + 'px';
          const im = img(r.img, 'sk-strip'); im.style.width = r.scrollWidth + 'px'; im.style.height = r.h + 'px';
          hi.appendChild(im); box.appendChild(hi); inner.appendChild(box);
          strips[r.id] = hi;
        }
        placeStates(inner, sw.content, 'content', null);
        for (const g of groups) if (g.z === 'content') addGroup(g.hs ? strips[g.hs] : inner, g, g.hs ? [] : sw.content);
        sc.appendChild(inner);
        scr.appendChild(sc);
      }
      if (s.above) scr.appendChild(img(s.above, 'sk-above'));
      placeStates(scr, sw.above, 'above', null);
      for (const m of s.masks || []) scr.appendChild(px(el('div', 'sk-block'), m));
      for (const g of groups) if (g.z === 'above') addGroup(scr, g, sw.above);
      return scr;
    }
    const screenEl = id => { if (!cache.has(id)) cache.set(id, build(byId[id])); return cache.get(id); };

    function preload(id) {
      const s = byId[id];
      if (!s || preloaded.has(id)) return;
      preloaded.add(id);
      for (const src of [s.chrome, s.content && s.content.src, s.above]) if (src) { const i = new Image(); i.decoding = 'async'; i.src = base + src; }
    }
    function preloadNeighbours(id) {
      for (const h of byId[id].hotspots) if (h.action.to) preload(h.action.to);
    }
    function ready(scr) {
      const imgs = [...scr.querySelectorAll('img')];
      const all = Promise.all(imgs.map(i => (i.decode ? i.decode().catch(() => {}) : Promise.resolve())));
      return Promise.race([all, sleep(400)]);
    }
    function resetScroll(scr) { const sc = scr.querySelector('.sk-scroll'); if (sc) sc.scrollTop = 0; for (const r of scr.querySelectorAll('.sk-hscroll')) r.scrollLeft = 0; }

    function clearTimers() { timers.forEach(clearTimeout); timers = []; }
    function arrive(id) {
      live.textContent = nameOf(id);
      for (const h of byId[id].hotspots) {
        if (h.trigger !== 'timer') continue;
        timers.push(setTimeout(() => { if (cur === id && !busyFlag) fire(h); }, h.timeoutMs || 0));
      }
      preloadNeighbours(id);
    }

    function mount(scr) {
      for (const n of root.querySelectorAll('.sk-scr.is-current')) n.classList.remove('is-current');
      scr.classList.add('is-current');
      scr.style.zIndex = '';
      root.appendChild(scr);
      resetScroll(scr);
    }

    async function transit(fromId, toId, t, reverse, via) {
      const my = ++gen;
      const hadFocus = root.contains(document.activeElement);
      busyFlag = true;
      clearTimers();
      const eff = reduced ? { type: 'fade', ms: 120 } : { type: t.type || 'instant', direction: t.direction, ms: t.ms || 0 };
      const outEl = curEl, inEl = screenEl(toId);
      cur = toId; curEl = inEl;
      emit('navigate', { from: fromId, to: toId, via, transition: { type: eff.type, direction: eff.direction, ms: eff.ms, reverse } });
      inEl.style.visibility = 'hidden';
      mount(inEl);
      await ready(inEl);
      if (my !== gen) return; // restarted meanwhile (possibly into this same screen, which arrives on its own)
      inEl.style.visibility = '';
      if (outEl && outEl !== inEl && eff.type !== 'instant' && eff.ms > 0) {
        const p = plan(eff);
        const A = reverse ? inEl : outEl, B = reverse ? outEl : inEl;
        (p.top === 'A' ? A : B).style.zIndex = '2';
        (p.top === 'A' ? B : A).style.zIndex = '1';
        const o = { duration: eff.ms, fill: 'both', easing: bez(reverse ? mirror(p.ease) : p.ease), direction: reverse ? 'reverse' : 'normal' };
        running = [];
        if (p.A) running.push(A.animate(p.A, o));
        if (p.B) running.push(B.animate(p.B, o));
        try { await Promise.all(running.map(a => a.finished)); } catch (e) { /* cancelled by restart */ }
        if (my !== gen) return;
        running.forEach(a => a.cancel()); running = [];
      }
      if (outEl && outEl !== inEl) { outEl.remove(); outEl.style.zIndex = ''; }
      inEl.style.zIndex = '';
      busyFlag = false;
      if (hadFocus) inEl.focus({ preventScroll: true });
      arrive(toId);
    }

    function go(to, t, via) {
      if (busyFlag || !byId[to]) return Promise.resolve(false);
      const tr = t || INSTANT;
      hist.push({ id: to, t: tr });
      return transit(cur, to, tr, false, via == null ? null : via).then(() => true);
    }
    function back(via) {
      if (busyFlag || hist.length < 2) return Promise.resolve(false);
      const top = hist.pop();
      return transit(top.id, hist[hist.length - 1].id, top.t, true, via == null ? 'back' : via).then(() => true);
    }
    function restart(id) {
      if (!byId[id]) return;
      gen++;
      clearTimers();
      running.forEach(a => { try { a.cancel(); } catch (e) { /* ignore */ } });
      running = []; press = null;
      for (const n of [...root.querySelectorAll('.sk-scr')]) { n.remove(); n.style.zIndex = ''; n.style.visibility = ''; }
      const from = cur;
      clearStates();
      hist = [{ id, t: INSTANT }];
      cur = id; curEl = screenEl(id);
      mount(curEl);
      busyFlag = false;
      emit('navigate', { from, to: id, via: 'restart', transition: { type: 'instant', ms: 0, reverse: false } });
      arrive(id);
    }
    function fire(h) {
      if (h.action.kind === 'state') {
        setState(h.action.screen, h.action.state, h.action.to);
        live.textContent = `${h.label || h.action.state}: ${short(h.action.to)}`;
        return Promise.resolve(true);
      }
      if (h.action.kind === 'back') return back(h.id);
      return go(h.action.to, h.action.transition, h.id);
    }

    // ---- input ----
    function toScreen(cx, cy) {
      const r = root.getBoundingClientRect();
      return { x: Math.round((cx - r.left) * FW / r.width * 10) / 10, y: Math.round((cy - r.top) * FH / r.height * 10) / 10, k: r.height / FH };
    }
    function candidates(cx, cy) {
      const out = [];
      for (const e of document.elementsFromPoint(cx, cy)) {
        if (!curEl || !curEl.contains(e)) continue;
        if (e.classList.contains('sk-block')) break;
        const g = groupOf.get(e);
        if (g) out.push(g);
      }
      return out;
    }
    const first = (cands, trig) => { for (const g of cands) if (g[trig]) return g[trig]; return null; };
    function flash() {
      clearTimeout(flashT);
      root.classList.remove('flash'); void root.offsetWidth; root.classList.add('flash');
      flashT = setTimeout(() => root.classList.remove('flash'), FLASH_MS);
    }
    function tap(cx, cy, h) {
      const p = toScreen(cx, cy);
      emit('tap', { screen: cur, x: p.x, y: p.y, hit: !!h, target: h ? h.id : null });
      if (h) fire(h); else flash();
    }

    root.addEventListener('pointerdown', e => {
      if (!e.isPrimary || e.button > 0 || busyFlag) return;
      const cands = candidates(e.clientX, e.clientY);
      const drag = first(cands, 'drag');
      const scroller = e.target.closest ? e.target.closest('.sk-scroll') : null;
      const row = e.target.closest ? e.target.closest('.sk-hscroll') : null;
      press = { id: e.pointerId, x0: e.clientX, y0: e.clientY, cands, drag, scroller, st0: scroller ? scroller.scrollTop : 0,
        row, sl0: row ? row.scrollLeft : 0, axis: null, moved: false, done: false, mouse: e.pointerType === 'mouse' };
      if (drag || ((scroller || row) && press.mouse)) { try { root.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } }
      if (drag) e.preventDefault();
    });
    root.addEventListener('pointermove', e => {
      if (!press || e.pointerId !== press.id || press.done) return;
      const dx = e.clientX - press.x0, dy = e.clientY - press.y0;
      if (!press.moved && Math.hypot(dx, dy) > DRAG_PX) press.moved = true;
      if (!press.moved) return;
      if (press.drag) {
        press.done = true;
        const h = press.drag; press = null;
        if (!busyFlag) tap(e.clientX, e.clientY, h);
      } else if (press.mouse) { // touch scrolls natively; a mouse drag scrolls the row it started on, or the page
        press.axis = press.axis || (press.row && Math.abs(dx) > Math.abs(dy) ? 'x' : 'y');
        const k = toScreen(0, 0).k;
        if (press.axis === 'x') press.row.scrollLeft = press.sl0 - dx / k;
        else if (press.scroller) press.scroller.scrollTop = press.st0 - dy / k;
      }
    });
    root.addEventListener('pointerup', e => {
      if (!press || e.pointerId !== press.id) return;
      const p = press; press = null;
      if (p.moved || busyFlag) return;
      tap(p.x0, p.y0, first(p.cands, 'click'));
    });
    root.addEventListener('pointercancel', () => { press = null; });
    root.addEventListener('dragstart', e => e.preventDefault());
    // Keyboard activation (Enter/Space on a focused hotspot) arrives as a click with detail 0.
    root.addEventListener('click', e => {
      if (e.detail !== 0 || busyFlag) return;
      const b = e.target.closest ? e.target.closest('.sk-hs') : null;
      const g = b && groupOf.get(b);
      if (!g) return;
      const r = b.getBoundingClientRect();
      tap(r.left + r.width / 2, r.top + r.height / 2, g.click || g.drag);
    });

    const api = {
      go: (id, t) => go(id, t, null),
      back: () => back(null),
      restart,
      current: () => cur,
      history: () => hist.map(h => h.id),
      setHotspotsVisible: on => root.classList.toggle('show-hs', !!on),
      on: (type, fn) => { listeners[type].push(fn); return () => { listeners[type] = listeners[type].filter(f => f !== fn); }; },
      busy: () => busyFlag,
      screen: id => byId[id || cur],
      states: statesOf,
      setState: (sid, stateId, name) => setState(sid, stateId, name),
    };
    restart(opts.start && byId[opts.start] ? opts.start : (data.flows[0] && data.flows[0].screenId) || data.screens[0].id);
    return api;
  }

  window.Player = { create };
})();
