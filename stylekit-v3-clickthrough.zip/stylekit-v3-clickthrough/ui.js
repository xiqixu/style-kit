/* Style Kit v3 click-through — shell: device fit, Review panel, keyboard, mode switch. */
(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const h = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const k in attrs || {}) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'text') e.textContent = attrs[k];
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), attrs[k]);
      else if (attrs[k] != null && attrs[k] !== false) e.setAttribute(k, attrs[k] === true ? '' : attrs[k]);
    }
    for (const c of kids) if (c != null) e.append(c);
    return e;
  };
  const SECTIONS = ['Navigation', 'Main flow', 'Sheets & states', 'Fix states', 'Added'];
  const shortFlow = n => n.replace(/^v3\s*·\s*/, '');

  const SK = window.SK = { ready: false, mode: 'review', hooks: { navigate: [], tap: [], mode: [], restart: [], keys: [] } };

  async function boot() {
    const data = await fetch('data/screens.json').then(r => r.json());
    const byId = Object.fromEntries(data.screens.map(s => [s.id, s]));
    const P = Player.create($('#screen'), data, { start: data.flows[0].screenId });
    Object.assign(SK, { data, byId, P, flow: data.flows[0].screenId });
    window.P = P;

    const nHot = data.screens.reduce((a, s) => a + s.hotspots.length, 0);
    $('#stat').textContent = `iPhone 15 Pro · ${data.screens.length} screens · ${nHot} hotspots · exported ${new Date(data.exportedAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}`;

    // ---- device fit ----
    const stage = $('#stage'), fit = $('#fit'), device = $('#device');
    function layout() {
      const bare = window.innerWidth < 500;
      device.classList.toggle('bare', bare);
      const W = bare ? 393 : 433, H = bare ? 852 : 886;
      const cs = getComputedStyle(stage);
      const availW = stage.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      const stacked = window.innerWidth < 900;
      let extra = 0; // task strip and key hints share the stage with the phone
      for (const c of stage.children) if (c !== fit && c.offsetParent !== null) {
        const m = getComputedStyle(c); // margins count too: the task strip's 8 px top margin cut the phone's bottom off in Test mode
        extra += c.offsetHeight + (parseFloat(m.marginTop) || 0) + (parseFloat(m.marginBottom) || 0) + (parseFloat(cs.rowGap) || 0);
      }
      const availH = stacked
        ? window.innerHeight - $('.top').offsetHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - extra
        : stage.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - extra;
      // on a phone the whole screen stays in view: the smaller of the width and height fits wins
      const s = bare ? Math.max(0.3, Math.min(availW / W, availH / H)) : Math.max(0.42, Math.min(1, availW / W, availH / H));
      fit.style.width = (W * s) + 'px';
      fit.style.height = (H * s) + 'px';
      device.style.transform = `scale(${s})`;
    }
    layout();
    SK.layout = layout;
    window.addEventListener('resize', layout);
    if (window.ResizeObserver) new ResizeObserver(layout).observe(stage);

    // ---- flows ----
    const flowBox = $('#flows');
    for (const f of data.flows) {
      flowBox.append(h('button', { type: 'button', class: 'flow', 'data-screen': f.screenId, 'aria-pressed': String(f.screenId === SK.flow), onclick: () => startFlow(f.screenId) },
        h('b', { text: shortFlow(f.name) }), h('span', { text: 'Starts at ' + (byId[f.screenId] ? byId[f.screenId].name : '?') }), h('i')));
    }
    function startFlow(id) {
      SK.flow = id;
      for (const b of flowBox.children) b.setAttribute('aria-pressed', String(b.dataset.screen === id));
      P.restart(id);
    }
    SK.startFlow = startFlow;

    // ---- screen list ----
    const tabs = $('#screen-tabs'), grid = $('#screen-grid');
    let section = byId[P.current()].section;
    function renderTabs() {
      tabs.replaceChildren(...SECTIONS.map(sec => h('button', { type: 'button', role: 'tab', 'data-section': sec, 'aria-selected': String(sec === section),
        title: data.screens.filter(s => s.section === sec).length + ' screens',
        onclick: () => { section = sec; renderTabs(); renderGrid(); } }, sec)));
    }
    function renderGrid() {
      grid.setAttribute('aria-label', section);
      grid.replaceChildren(...data.screens.filter(s => s.section === section).map(s =>
        h('button', { type: 'button', class: 'thumb', 'data-screen': s.id, 'aria-current': String(s.id === P.current()), onclick: () => P.restart(s.id) },
          h('img', { src: s.thumb, alt: '', loading: 'lazy', width: 72, height: 156 }), h('span', { text: s.name }))));
    }
    renderTabs(); renderGrid();

    // ---- now / trail ----
    let trail = [];
    function renderNow() {
      const s = byId[P.current()];
      $('#now-name').textContent = s.name;
      const n = s.hotspots.filter(x => x.trigger !== 'timer').length, t = s.hotspots.find(x => x.trigger === 'timer');
      $('#now-meta').textContent = `${s.section} · ${n} hotspot${n === 1 ? '' : 's'}${s.content ? ' · scrolls' : ''}${t ? ` · auto-advances after ${(t.timeoutMs / 1000).toFixed(1)} s` : ''}`;
      $('#trail').replaceChildren(...trail.slice(-5).map(e => h('li', null, byId[e.to].name, e.kind ? h('span', { class: 'via', text: e.kind }) : null)));
      if (s.section !== section) { section = s.section; renderTabs(); renderGrid(); }
      else for (const b of grid.children) b.setAttribute('aria-current', String(b.dataset.screen === s.id));
    }
    P.on('navigate', e => {
      if (e.via === 'restart') trail = [{ to: e.to }];
      else {
        const viaH = e.via && byId[e.from] ? byId[e.from].hotspots.find(x => x.id === e.via) : null;
        trail.push({ to: e.to, kind: e.transition.reverse ? 'back' : viaH && viaH.trigger !== 'click' ? viaH.trigger : null });
      }
      if (trail.length > 20) trail = trail.slice(-5);
      renderNow();
      for (const fn of SK.hooks.navigate) fn(e);
    });
    // In Review, a tap on something Figma never linked says so (the hotspot flash alone reads as a broken click).
    const missNote = $('#miss-note'); let missT = 0;
    P.on('tap', e => {
      if (!e.hit && SK.mode === 'review') { missNote.hidden = false; clearTimeout(missT); missT = setTimeout(() => { missNote.hidden = true; }, 1600); }
      else if (e.hit) { missNote.hidden = true; }
      for (const fn of SK.hooks.tap) fn(e);
    });
    trail = [{ to: P.current() }];
    renderNow();

    // ---- hotspots, restart, keys ----
    const toggle = $('#hotspots-toggle');
    const setHot = on => { toggle.checked = on; P.setHotspotsVisible(on && SK.mode === 'review'); };
    toggle.addEventListener('change', () => setHot(toggle.checked));
    SK.setHotspots = setHot;
    function restart() {
      for (const fn of SK.hooks.restart) if (fn() === true) return;
      P.restart(SK.flow);
    }
    $('#restart').addEventListener('click', restart);
    document.addEventListener('keydown', e => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      for (const fn of SK.hooks.keys) if (fn(e) === true) return;
      if (e.key === 'ArrowLeft' || e.key === 'Backspace') { e.preventDefault(); P.back(); }
      else if (e.key === 'r' || e.key === 'R') { e.preventDefault(); restart(); }
      else if ((e.key === 'h' || e.key === 'H') && SK.mode === 'review') { e.preventDefault(); setHot(!toggle.checked); }
    });

    // ---- mode switch ----
    function setMode(m) {
      SK.mode = m;
      $('#mode-review').setAttribute('aria-checked', String(m === 'review'));
      $('#mode-test').setAttribute('aria-checked', String(m === 'test'));
      $('#panel-review').hidden = m !== 'review';
      $('#panel-test').hidden = m !== 'test';
      document.body.dataset.mode = m;
      $('#miss-note').hidden = true;
      P.setHotspotsVisible(m === 'review' && toggle.checked);
      for (const fn of SK.hooks.mode) fn(m);
    }
    SK.setMode = setMode;
    $('#mode-review').addEventListener('click', () => setMode('review'));
    $('#mode-test').addEventListener('click', () => setMode('test'));
    $('.seg').addEventListener('keydown', e => {
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
      e.preventDefault(); e.stopPropagation();
      const m = SK.mode === 'review' ? 'test' : 'review'; setMode(m); $('#mode-' + m).focus();
    });

    await initTest(SK);
    SK.ready = true;
  }

  // ---------------------------------------------------------------- Test mode
  const CSV_TASKS = ['participant', 'task', 'outcome', 'ms', 'taps', 'misses', 'path'];
  const CSV_TAPS = ['participant', 'task', 't', 'screen', 'x', 'y', 'hit', 'target'];
  const cell = v => { const t = Array.isArray(v) ? v.join(' > ') : String(v == null ? '' : v); return /[",\n\r]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t; };
  const toCsv = (cols, list) => [cols.join(','), ...list.map(r => cols.map(c => cell(r[c])).join(','))].join('\n') + '\n';
  const safeId = s => (s || 'anon').replace(/[^A-Za-z0-9_.~:@+-]+/g, '_').slice(0, 60) || 'anon';
  const fmtMs = ms => (ms / 1000).toFixed(1) + ' s';
  const OUTCOME = { success: 'Reached goal', 'gave-up': 'Gave up', 'done-not-goal': 'Done, not at goal' };

  async function initTest(SK) {
    const { P, byId } = SK;
    const tasks = await fetch('data/tasks.json').then(r => r.json());
    const results = SK.results = { rows: [], taps: [] };
    const st = { participant: '', index: 0, active: null };
    const caps = { db: null, downloads: null, uid: null };
    const use = name => (window.claude && typeof window.claude.use === 'function')
      ? Promise.resolve(window.claude.use(name)).catch(() => null) : Promise.resolve(null);
    use('downloads').then(x => { caps.downloads = x; });
    // Each tester writes under results/<their id>/tasks; only the owner and editors read everyone's.
    Promise.all([use('db'), use('user')]).then(async ([db, user]) => {
      const uid = user && typeof user.id === 'function' ? await user.id().catch(() => null) : null;
      if (db && uid) { caps.db = db; caps.uid = uid; }
      renderStore();
    });

    const input = $('#participant'), note = $('#store-note');
    let storeMsg = '';
    function renderStore() {
      note.classList.toggle('warn', !!storeMsg);
      note.textContent = storeMsg || (caps.db ? 'Each finished task is also saved to this page’s shared results.' : 'Results stay in this tab until you export them.');
    }
    // Each participant ID has its own place in the task list: a new ID starts at task 1, a known one resumes.
    input.addEventListener('input', () => {
      st.participant = input.value.trim();
      if (!st.active) st.index = Math.min(tasks.length, mine().length);
      render();
    });

    const mine = () => results.rows.filter(r => r.participant === st.participant);
    const myTaps = () => results.taps.filter(r => r.participant === st.participant);
    SK.csv = kind => kind === 'taps' ? toCsv(CSV_TAPS, myTaps()) : toCsv(CSV_TASKS, mine());

    const met = (task, path, cur) => task.goals.includes(cur) && (!task.via || path.some(id => task.via.includes(id)));

    function start() {
      if (st.active || st.index >= tasks.length) return;
      if (!st.participant) { input.focus(); storeMsg = 'Enter a participant ID to start.'; renderStore(); return; }
      storeMsg = ''; renderStore();
      const task = tasks[st.index];
      st.active = { task, start: Date.now(), ids: [], names: [], taps: 0, misses: 0, tapRows: [] };
      P.restart(task.start);
      render();
    }
    function finish(outcome) {
      const a = st.active; if (!a) return;
      st.active = null;
      const end = Date.now();
      const row = { participant: st.participant, task: a.task.id, start: a.start, end, ms: end - a.start, outcome, path: a.names, taps: a.taps, misses: a.misses };
      results.rows.push(row);
      results.taps.push(...a.tapRows);
      st.index++;
      save(row, a.tapRows); // the goal screen stays up; Start loads the next task's first screen
      render();
    }
    async function save(row, tapRows) {
      if (!caps.db) return;
      try {
        await caps.db.doc('results/' + caps.uid).collection('tasks').doc(safeId(row.participant) + '-' + row.task + '-' + row.start)
          .set({ ...row, tapLog: tapRows, prototype: 'Style Kit v3', exportedAt: SK.data.exportedAt });
      } catch (e) {
        storeMsg = 'Saved locally only: the shared results store refused this task. Export the CSV before closing.';
        renderStore();
      }
    }
    function done() {
      const a = st.active; if (!a) return;
      finish(met(a.task, a.ids, P.current()) ? 'success' : 'done-not-goal');
    }

    SK.hooks.navigate.push(e => {
      const a = st.active; if (!a || SK.mode !== 'test') return;
      a.ids.push(e.to); a.names.push(byId[e.to].name);
      if (e.via !== 'restart' && met(a.task, a.ids.slice(0, -1), e.to)) finish('success');
    });
    SK.hooks.tap.push(e => {
      const a = st.active; if (!a || SK.mode !== 'test') return;
      a.taps++; if (!e.hit) a.misses++;
      a.tapRows.push({ participant: st.participant, task: a.task.id, t: Date.now() - a.start, screen: byId[e.screen].name, x: e.x, y: e.y, hit: e.hit, target: e.target || '' });
    });
    SK.hooks.restart.push(() => {
      if (SK.mode !== 'test') return false;
      const t = st.active ? st.active.task : tasks[Math.min(st.index, tasks.length - 1)];
      P.restart(t.start);
      return true;
    });
    SK.hooks.mode.push(m => {
      if (m === 'test') { if (st.index < tasks.length) P.restart(tasks[st.index].start); }
      else if (st.active) st.active = null; // leaving Test discards an unfinished task
      render();
    });

    $('#task-start').addEventListener('click', start);
    $('#strip-start').addEventListener('click', start);
    $('#task-done').addEventListener('click', done);
    $('#strip-done').addEventListener('click', done);
    $('#task-giveup').addEventListener('click', () => finish('gave-up'));
    $('#strip-giveup').addEventListener('click', () => finish('gave-up'));
    $('#new-participant').addEventListener('click', () => {
      if (st.active) return;
      st.index = 0; input.value = ''; st.participant = ''; storeMsg = '';
      $('#export-text').hidden = true; $('#export-note').textContent = '';
      P.restart(tasks[0].start); renderStore(); render(); input.focus();
    });

    // Export: downloads capability → clipboard → selectable text.
    function exportCsv(kind) {
      const list = kind === 'taps' ? myTaps() : mine();
      const out = $('#export-note');
      if (!list.length) { out.textContent = 'Finish a task first. There is nothing to export yet.'; return; }
      const csv = SK.csv(kind);
      const name = `stylekit-v3-test-${safeId(st.participant)}${kind === 'taps' ? '-taps' : ''}.csv`;
      if (caps.downloads) {
        caps.downloads.save({ filename: name, data: csv })
          .then(() => { out.textContent = 'Saved ' + name + '.'; })
          .catch(e => { if (e && e.code === 'declined') out.textContent = 'Export cancelled.'; else showText(csv, false); });
        return;
      }
      showText(csv, true);
    }
    function showText(csv, tryClipboard) {
      const ta = $('#export-text'), out = $('#export-note');
      ta.hidden = false; ta.value = csv; ta.focus(); ta.setSelectionRange(0, csv.length);
      out.textContent = 'The CSV is selected below. Copy it into a spreadsheet.';
      if (tryClipboard && navigator.clipboard && navigator.clipboard.writeText) {
        try { navigator.clipboard.writeText(csv).then(() => { out.textContent = 'Copied to the clipboard. The CSV is also selected below.'; }, () => {}); } catch (e) { /* keep the textarea */ }
      }
    }
    $('#export').addEventListener('click', () => exportCsv('tasks'));
    $('#export-taps').addEventListener('click', () => exportCsv('taps'));

    function render() {
      const a = st.active, n = st.index, total = tasks.length, finished = n >= total;
      const outcomeOf = i => { const r = mine().find(x => x.task === tasks[i].id); return r ? r.outcome : null; };
      $('#tasks').replaceChildren(...tasks.map((t, i) => {
        const o = outcomeOf(i);
        const state = a && i === n ? 'active' : o ? 'done' : i === n ? 'next' : 'pending';
        // Only finished, current and next tasks show their wording (spec: one task at a time).
        return h('li', { 'data-state': state }, h('span', { text: state === 'pending' ? 'Not started' : t.text }),
          state === 'active' ? h('span', { class: 'chip active', text: 'In progress' }) : o ? h('span', { class: 'chip ' + o, text: OUTCOME[o] }) : null);
      }));
      $('#task-start').hidden = !!a || finished;
      $('#task-start').textContent = 'Start task ' + (n + 1);
      $('#task-done').hidden = $('#task-giveup').hidden = !a;
      input.disabled = !!a;
      $('#new-participant').disabled = !!a;
      const strip = $('#task-strip');
      strip.hidden = SK.mode !== 'test';
      $('#strip-n').textContent = finished ? 'All tasks done' : `Task ${n + 1} of ${total}`;
      $('#strip-text').textContent = finished ? 'Thank you. The moderator will take it from here.' : tasks[n].text;
      $('#strip-start').hidden = !!a || finished;
      $('#strip-done').hidden = $('#strip-giveup').hidden = !a;
      renderSummary();
      if (SK.layout) SK.layout();
    }
    function renderSummary() {
      const list = mine();
      $('#summary tbody').replaceChildren(...(list.length ? list.map(r => h('tr', null,
        h('td', { text: String(tasks.findIndex(t => t.id === r.task) + 1) }),
        h('td', null, h('span', { class: 'chip ' + r.outcome, text: OUTCOME[r.outcome] })),
        h('td', { class: 'num', text: fmtMs(r.ms) }), h('td', { class: 'num', text: r.taps }), h('td', { class: 'num', text: r.misses })))
        : [h('tr', { class: 'empty' }, h('td', { colspan: 5, text: 'Finished tasks appear here.' }))]));
    }
    renderStore();
    render();
  }

  boot().catch(err => {
    const p = $('#stat'); if (p) p.textContent = 'Could not load the prototype data: ' + err.message;
    console.error(err);
  });
})();
